# CMD-X
CMD-X is the leading FE admin script for ROBLOX exploiting. CMD-X is not a competitor, CMD-X is the competition.
With over 600 commands and updates coming in daily or bi-daily, we can assure you that CMD-X is the best of the best.
Not satisfied with the look of CMD-X? Request or create and use a theme.
While we do have plug-in support, we really don't see what you'd need to add onto CMD-X.

Discord: discord.gg/cmd
