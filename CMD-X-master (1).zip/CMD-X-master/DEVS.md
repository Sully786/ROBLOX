https://github.com/CMD-X
https://github.com/knifemarks
https://github.com/Luyler
https://github.com/Curvn
